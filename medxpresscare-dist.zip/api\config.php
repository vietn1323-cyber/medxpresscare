<?php
// Cấu hình tài khoản Quản Trị Viên & Bảo mật MedXpressCare Backend
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Mật khẩu và tài khoản Admin mặc định (Bạn có thể đổi mật khẩu tại đây)
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD_HASH', password_hash('MedXpress@2026', PASSWORD_DEFAULT)); // Mật khẩu mặc định: MedXpress@2026
define('SECRET_KEY', 'medxpresscare_secure_token_key_2026_xyz');

// File lưu dữ liệu bảo mật (người ngoài không tải được vì có .htaccess chặn)
define('DATA_DIR', __DIR__ . '/../data_storage');
define('ORDERS_FILE', DATA_DIR . '/orders.json');
define('PRODUCTS_FILE', DATA_DIR . '/products.json');

// Khởi tạo thư mục dữ liệu bảo mật nếu chưa có
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
    // Tạo file .htaccess chặn người ngoài tải file dữ liệu
    file_put_contents(DATA_DIR . '/.htaccess', "Deny from all\n");
}

// Hàm kiểm tra Token xác thực của Admin
function verifyAdminToken() {
    $headers = getallheaders();
    $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';
    if (!$authHeader && isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    }

    if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        $token = $matches[1];
        $expected = hash_hmac('sha256', ADMIN_USERNAME, SECRET_KEY);
        if (hash_equals($expected, $token)) {
            return true;
        }
    }
    return false;
}
