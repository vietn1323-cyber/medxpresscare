<?php
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];

// 1. KHÁCH ĐẶT HÀNG (POST) - Ai cũng có thể tạo đơn hàng
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || empty($input['id']) || empty($input['customer'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Dữ liệu đơn hàng không hợp lệ']);
        exit;
    }

    $orders = [];
    if (file_exists(ORDERS_FILE)) {
        $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    }

    // Thêm đơn hàng mới lên đầu danh sách
    array_unshift($orders, $input);
    file_put_contents(ORDERS_FILE, json_encode($orders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    // Phản hồi thành công
    echo json_encode([
        'success' => true,
        'message' => 'Đơn hàng đã được lưu an toàn trên máy chủ backend',
        'orderId' => $input['id']
    ]);
    exit;
}

// 2. XEM DANH SÁCH ĐƠN HÀNG (GET) - CHỈ QUẢN TRỊ VIÊN MỚI ĐƯỢC XEM
if ($method === 'GET') {
    if (!verifyAdminToken()) {
        http_response_code(403);
        echo json_encode([
            'success' => false, 
            'message' => 'Quyền truy cập bị từ chối: Chỉ quản trị viên đã đăng nhập mới có quyền xem đơn hàng.'
        ]);
        exit;
    }

    $orders = [];
    if (file_exists(ORDERS_FILE)) {
        $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    }

    echo json_encode([
        'success' => true,
        'orders' => $orders
    ]);
    exit;
}

// 3. CẬP NHẬT TRẠNG THÁI ĐƠN HÀNG (PUT) - CHỈ QUẢN TRỊ VIÊN
if ($method === 'PUT') {
    if (!verifyAdminToken()) {
        http_response_code(403);
        echo json_encode([
            'success' => false, 
            'message' => 'Quyền truy cập bị từ chối: Chỉ quản trị viên mới có quyền cập nhật đơn hàng.'
        ]);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    $orderId = isset($input['orderId']) ? $input['orderId'] : '';
    $status = isset($input['status']) ? $input['status'] : '';

    if (!$orderId || !$status) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Thiếu thông tin đơn hàng']);
        exit;
    }

    $orders = [];
    if (file_exists(ORDERS_FILE)) {
        $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    }

    $updated = false;
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            $o['status'] = $status;
            $updated = true;
            break;
        }
    }

    if ($updated) {
        file_put_contents(ORDERS_FILE, json_encode($orders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(['success' => true, 'message' => 'Đã cập nhật trạng thái đơn']);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy đơn hàng']);
    }
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
