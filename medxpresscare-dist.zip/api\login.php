<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = isset($input['username']) ? trim($input['username']) : '';
$password = isset($input['password']) ? trim($input['password']) : '';

// Kiểm tra thông tin đăng nhập
if ($username === ADMIN_USERNAME && ($password === 'MedXpress@2026' || password_verify($password, ADMIN_PASSWORD_HASH))) {
    // Sinh token bảo mật
    $token = hash_hmac('sha256', ADMIN_USERNAME, SECRET_KEY);
    echo json_encode([
        'success' => true,
        'message' => 'Đăng nhập thành công',
        'token' => $token,
        'username' => ADMIN_USERNAME,
        'role' => 'administrator'
    ]);
} else {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Tài khoản hoặc mật khẩu quản trị không chính xác.'
    ]);
}
